<?php
    define("HOST","localhost");
    define("USER","root");
    define("PASS","");
    define("NAME","aximwbkh_axil");
    $con = mysqli_connect(HOST, USER, PASS, NAME);


// define("DB_HOST", "localhost");
// define("DB_USER", "bumnupnm_aximwbkh_axil");
// define("DB_PASS", "bumnupnm_aximwbkh_axil");
// define("DB_NAME", "bumnupnm_aximwbkh_axil");
// $db_con = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
// $domain = 'https://fineasespace.com/';

// $domain = 'http://localhost/public_html/';

$domain = 'https://fineasespace.com/';


$sitename =' Fin Ease Space';
$siteemail = 'support@fineasespace.com';
?>
